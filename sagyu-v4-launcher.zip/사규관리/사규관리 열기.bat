@echo off
rem --- Open sagyu-v4.html as an app window (no install needed) ---
setlocal
set "HERE=%~dp0"
set "APP=%HERE%sagyu-v4.html"
set "DATA=%HERE%appdata"

if not exist "%APP%" (
  echo.
  echo  [X] sagyu-v4.html is missing. Keep it in the same folder as this file.
  echo.
  pause
  exit /b 1
)

set "BR="
if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "BR=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if not defined BR if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BR=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BR if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set "BR=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not defined BR if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BR=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BR if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" set "BR=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not defined BR if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BR=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if not defined BR (
  rem No Edge or Chrome found - open with the default browser
  start "" "%APP%"
  exit /b 0
)

set "URL=file:///%APP:\=/%"
start "" "%BR%" --app="%URL%" --user-data-dir="%DATA%" --no-first-run --no-default-browser-check
exit /b 0
